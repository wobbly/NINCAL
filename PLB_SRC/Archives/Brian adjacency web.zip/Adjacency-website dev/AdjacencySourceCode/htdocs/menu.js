function doMenuItem(destination)
{
   document.menuForm.action = destination;
   document.menuForm.submit();
}

function exitSite(newURL)
{
   window.open(newURL, 'exitwindow');
}

function doMenuItemUsermaint()
{
   document.usermaintForm.submit();
}

function setStatus(newStatus)
{
	window.status = newStatus;
}
